# Segmentación del fondo en vídeo.
