// ----------------------------------------
// seglib.cpp
// (c) FSIV, University of Cordoba
// ----------------------------------------

#include "common_code.hpp"
#include <opencv2/imgproc.hpp>

void fsiv_remove_segmentation_noise(cv::Mat & img, int r)
{
    CV_Assert(img.type()==CV_8UC1);
    CV_Assert(r>0);
    //TODO
    //Apply a closing+opening using a square structuring element with radius r.

    //
}

void fsiv_segm_by_dif(const cv::Mat & prevFrame, const cv::Mat & curFrame,
                      cv::Mat & difimg, int thr, int r)
{
    CV_Assert(prevFrame.type()==CV_8UC3 && prevFrame.type()==curFrame.type());
    CV_Assert(prevFrame.size()==prevFrame.size());

    //TODO
    //Remenber: use >= to compare with 'thr'.

    //
    CV_Assert(difimg.type()==CV_8UC1);
    CV_Assert(difimg.size()==curFrame.size());
}

void fsiv_apply_mask(const cv::Mat & frame, const cv::Mat & mask,
                     cv::Mat & outframe)
{
    CV_Assert(frame.type()==CV_8UC1 || frame.type()==CV_8UC3);
    CV_Assert(mask.type()==CV_8UC1);
    CV_Assert(frame.size()==mask.size());

    //TODO
    //Remenber: frame could have 3 channels.



    //
    CV_Assert(outframe.type()==frame.type());
    CV_Assert(outframe.size()==frame.size());
}

bool
fsiv_learn_gaussian_model(cv::VideoCapture & input,
                          cv::Mat & mean,
                          cv::Mat & variance,
                          int num_frames,
                          int gauss_r,
                          const char * wname)
{
    CV_Assert(input.isOpened());
    bool was_ok = true;

    //TODO
    // Remenber you can compute the variance as:
    // varI = sum_n{I^2}/n - meanI²
    // Hint: convert to input frames to float [0,1].
    // Hint: use cv::accumulate() and cv::accumulateSquare().


    //
    CV_Assert(!was_ok || mean.type()==CV_32FC3);
    CV_Assert(!was_ok || variance.type()==CV_32FC3);
    return was_ok;
}

void
fsiv_segm_by_gaussian_model(const cv::Mat & frame,
                            cv::Mat & mask,
                            const cv::Mat & mean,
                            const cv::Mat & variance, float k, int r)
{
    CV_Assert(frame.type()==CV_32FC3);

    //TODO
    //Remenber: a point belongs to the foreground (255) if |mean-I| >= k*stdev


    //
    CV_Assert(mask.type()==CV_8UC1);
}

void
fsiv_update_gaussian_model(const cv::Mat & frame,
                           const cv::Mat & mask,
                           unsigned long frame_count,
                           cv::Mat & mean,
                           cv::Mat & variance,
                           float alpha,
                           unsigned short_term_update_period,
                           unsigned long_term_update_period)
{
    CV_Assert(frame.type()==CV_32FC3);
    CV_Assert(mask.type()==CV_8UC1);
    CV_Assert(mean.type()==CV_32FC3);
    CV_Assert(variance.type()==CV_32FC3);
    CV_Assert(frame.size()==mask.size());

    //TODO
    //Remember: In the short term updating you must update the model using
    //the background only (not mask).
    //However in the long term updating you must update
    //the model using both background and foreground (without mask).
    //Hint: a period is met when (idx % period) == 0
    //Hint: use accumulateWeighted to update the model.


    //
}
